package com.example.listviewpresidenherlina.model

class Pres {
    var nama: String = ""
    var deskripsi: String = ""
    var gambar: Int = 0
}